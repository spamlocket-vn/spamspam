echo " Phiên bản screen: $(screen --version)"
echo " Phiên bản go: $(go version)"
echo " Phiên bản zmap: $(zmap --version)"
